//Bryant Wong CSCi 2421 Homework 2
#include "ArrayBag.h"
#include <fstream>

#ifndef SET_
#define SET_

//prototype for GetIntsFromFile
bool getIntsFromFile(std::ifstream& file, ArrayBag& bag);	//passes a reference of the opened file and the array



#endif